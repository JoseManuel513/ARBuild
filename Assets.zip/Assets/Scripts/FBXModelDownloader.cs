using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.IO;
using TMPro;
using System.Collections.Generic;

public class FBXModelDownloader : MonoBehaviour
{
    [Header("Configuraci�n")]
    public string downloadID = "TU_ID_AQUI";
    public string localFileName = "modelo.fbx";
    public Vector3 spawnPosition = Vector3.zero;
    public Transform spawnParent;
    public TextMeshProUGUI statusText;
    public List<GameObject> DataEdificio = new List<GameObject>();

    private GameObject currentModel;

    public void StartDownload(string downloadID)
    {
        StartCoroutine(DownloadAndLoadFBX(downloadID));
    }

    public IEnumerator DownloadAndLoadFBX(string modelID)
    {
        string modelUrl = $"https://drive.google.com/uc?export=download&id={modelID}";
        UpdateStatus("Descargando modelo FBX... ");

        string saveDir = Path.Combine(Application.persistentDataPath, "DownloadedModels");
        if (!Directory.Exists(saveDir))
            Directory.CreateDirectory(saveDir);

        string localFilePath = Path.Combine(saveDir, $"{modelID}.fbx");

        // Normalizar separadores
        localFilePath = Path.GetFullPath(localFilePath);

        using (UnityWebRequest www = UnityWebRequest.Get(modelUrl))
        {
            www.timeout = 30;
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                UpdateStatus("Error: " + www.error);
                yield break;
            }

            File.WriteAllBytes(localFilePath, www.downloadHandler.data);
        }

        UpdateStatus("Descarga FBX completa, procesando modelo...");
        Debug.Log("Archivo FBX descargado en: " + localFilePath);

        // Cargar modelo FBX
        yield return LoadFBXModel(localFilePath, modelID);
    }

    private IEnumerator LoadFBXModel(string path, string modelID)
    {
        if (!File.Exists(path))
        {
            UpdateStatus("Archivo FBX no encontrado en disco.");
            yield break;
        }

        // Verificar si el archivo parece v�lido (no HTML)
        byte[] fileBytes = File.ReadAllBytes(path);
        if (fileBytes.Length < 100) // Archivo muy peque�o, probablemente no es FBX
        {
            string fileContent = System.Text.Encoding.UTF8.GetString(fileBytes);
            if (fileContent.StartsWith("<!DOCTYPE html") || fileContent.Contains("Google Drive"))
            {
                UpdateStatus("Archivo descargado no es un FBX v�lido.");
                Debug.LogError("El archivo descargado no parece un FBX. Verifica la URL.");
                yield break;
            }
        }

        UpdateStatus("Procesando modelo FBX...");

        // Mover el archivo FBX a la carpeta Resources temporalmente para cargarlo
        string resourcesPath = CopyToResources(path, modelID);

        if (string.IsNullOrEmpty(resourcesPath))
        {
            UpdateStatus("Error al preparar el modelo FBX.");
            yield break;
        }

        // Cargar el FBX como GameObject
        GameObject fbxModel = Resources.Load<GameObject>(modelID);

        if (fbxModel != null)
        {
            // Instanciar el modelo
            GameObject modelInstance = Instantiate(fbxModel);
            modelInstance.name = $"Model_{modelID}";

            // Configurar el modelo
            SetupFBXModel(modelInstance);
            UpdateStatus("Modelo FBX cargado correctamente.");
        }
        else
        {
            UpdateStatus("Error: No se pudo cargar el modelo FBX desde Resources.");
            Debug.LogError($"No se pudo cargar el modelo FBX: {modelID}");
        }

        yield return null;
    }

    private string CopyToResources(string sourcePath, string modelID)
    {
        try
        {
            // Crear carpeta Resources temporal si no existe
            string resourcesDir = Path.Combine(Application.dataPath, "TempResources");
            if (!Directory.Exists(resourcesDir))
                Directory.CreateDirectory(resourcesDir);

            // Copiar archivo FBX a Resources temporal
            string destPath = Path.Combine(resourcesDir, $"{modelID}.fbx");
            File.Copy(sourcePath, destPath, true);

            // Forzar refresh de Assets para que Unity detecte el nuevo archivo
#if UNITY_EDITOR
            UnityEditor.AssetDatabase.Refresh();
#endif

            return destPath;
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Error copiando FBX a Resources: {e.Message}");
            return null;
        }
    }

    private void SetupFBXModel(GameObject model)
    {
        if (model == null)
        {
            Debug.LogWarning("Intento de agregar modelo FBX nulo a DataEdificio");
            return;
        }

        // Asegurar que cada modelo tenga un nombre �nico
        model.name = $"FBXModel_{DataEdificio.Count + 1}";

        // Asignar posici�n base o incremental
        if (spawnParent)
            model.transform.SetParent(spawnParent, false);

        model.transform.position = spawnPosition + new Vector3(0, 0, DataEdificio.Count * 2f);
        model.SetActive(false);

        // Agregar al listado
        DataEdificio.Add(model);

        Debug.Log($"Modelo FBX agregado a DataEdificio: {model.name}");
        UpdateStatus($"Modelo FBX {model.name} cargado correctamente.");
    }

private void UpdateStatus(string msg)
    {
        Debug.Log(msg);
        if (statusText)
            statusText.text = msg;
    }
}