using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.IO;
using TMPro;
using GLTFast;
using GLTFast.Loading;
using GLTFast.Materials;
using System.Threading.Tasks;
using System.Collections.Generic;

public class DriveDownloader : MonoBehaviour
{
    [Header("Configuraci�n")]
    public string downloadID = "TU_ID_AQUI";
    public string localFileName = "modelo.glb";
    public Vector3 spawnPosition = Vector3.zero;
    public Transform spawnParent;
    public TextMeshProUGUI statusText;
    public List<GameObject> DataEdificio = new List<GameObject>();

    private GameObject currentModel;

    public void StartDownload()
    {
        StartCoroutine(DownloadAndLoadGLB(downloadID));
    }

    public IEnumerator DownloadAndLoadGLB(string modelID)
    {
        string modelUrl = $"https://drive.google.com/uc?export=download&id={modelID}";
        UpdateStatus("Descargando modelo... ");

        string saveDir = Path.Combine(Application.persistentDataPath, "DownloadedModels");
        if (!Directory.Exists(saveDir))
            Directory.CreateDirectory(saveDir);

        string localFilePath = Path.Combine(saveDir, $"{modelID}.glb");

        // Normalizar separadores
        localFilePath = Path.GetFullPath(localFilePath);

        using (UnityWebRequest www = UnityWebRequest.Get(modelUrl))
        {
            www.timeout = 30;
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                UpdateStatus("Error: " + www.error);
                yield break;
            }

            File.WriteAllBytes(localFilePath, www.downloadHandler.data);
        }

        UpdateStatus("Descarga completa, cargando modelo...");
        Debug.Log(localFilePath);

        // Cargar modelo sin bloquear
        yield return LoadModelAsync(localFilePath, modelID);
    }

    private IEnumerator LoadModelAsync(string path, string modelID)
    {
        if (!File.Exists(path))
        {
            UpdateStatus("Archivo no encontrado en disco.");
            yield break;
        }

        // Verificar si el archivo parece v�lido (no HTML)
        string firstLine = File.ReadAllText(path, System.Text.Encoding.UTF8);
        if (firstLine.StartsWith("<!DOCTYPE html") || firstLine.Contains("Google Drive"))
        {
            UpdateStatus("Archivo descargado no es un .glb v�lido.");
            Debug.LogError("El archivo descargado no parece un GLB. Verifica la URL.");
            yield break;
        }

        var gltf = new GltfImport();
        Debug.Log("Lleg�...");

        var settings = new ImportSettings
        {
            GenerateMipMaps = true,
            AnisotropicFilterLevel = 2
        };

        // Cargar el archivo (asincr�nicamente)
        // Iniciar carga asincr�nica (Task)
        Task<bool> loadTask = gltf.Load(path, settings);

        // Esperar hasta que termine el Task
        while (!loadTask.IsCompleted)
        {
            UpdateStatus("Cargando modelo...");
            yield return null;
        }

        bool success = loadTask.Result;

        if (!success)
        {
            UpdateStatus("Error al cargar el modelo GLB.");
            yield break;
        }

        // Instanciar el modelo cargado
        var modelRoot = new GameObject($"Model_{modelID}");
                
        bool instantiated = gltf.InstantiateMainScene(modelRoot.transform);

        if (instantiated)
        {
            //ConvertMaterialsToURP(modelRoot);
            //FixMaterials(modelRoot);
            
            SetupModel(modelRoot);
            UpdateStatus("Modelo cargado correctamente.");
        }
        else
        {
            UpdateStatus("Error al instanciar el modelo.");
        }

        yield break;
    }
    private void FixMaterials(GameObject model)
    {
        Shader pbrShader = Shader.Find("Shader Graphs/glTF-pbrMetallicRoughness");
        Shader fallbackShader = Shader.Find("Universal Render Pipeline/Lit");

        if (pbrShader == null)
        {
            Debug.LogWarning("Shader 'Shader Graphs/glTF-pbrMetallicRoughness' no encontrado. Usando fallback URP Lit.");
        }

        Renderer[] renderers = model.GetComponentsInChildren<Renderer>(true);
        int fixedCount = 0;

        foreach (var renderer in renderers)
        {
            Material[] mats = renderer.materials;

            for (int i = 0; i < mats.Length; i++)
            {
                var mat = mats[i];
                if (mat == null) continue;

                // Si el shader no existe o est� roto
                if (mat.shader == null || mat.name.Contains("Missing"))
                {
                    mat.shader = pbrShader != null ? pbrShader : fallbackShader;
                    fixedCount++;
                }

                // Forzar reimportar propiedades visuales
                mat.EnableKeyword("_METALLICSPECGLOSSMAP");
                mat.EnableKeyword("_NORMALMAP");
            }

            renderer.materials = mats;
        }

        Debug.Log($"{fixedCount} materiales reparados en {model.name}");
    }

    private void ConvertMaterialsToURP(GameObject modelRoot)
    {
        Renderer[] renderers = modelRoot.GetComponentsInChildren<Renderer>(true);
        int materialsConverted = 0;

        foreach (Renderer renderer in renderers)
        {
            Material[] materials = renderer.sharedMaterials;

            for (int i = 0; i < materials.Length; i++)
            {
                if (materials[i] != null)
                {
                    // Cambiar directamente el shader sin crear nuevo material
                    Shader urpShader = Shader.Find("Universal Render Pipeline/Lit");
                    if (urpShader != null)
                    {
                        materials[i].shader = urpShader;
                        materialsConverted++;
                    }
                }
            }

            renderer.sharedMaterials = materials;
        }

        Debug.Log($"Convertidos {materialsConverted} materiales a URP en {modelRoot.name}");
    }

    private void SetupModel(GameObject model)
    {
        if (model == null)
        {
            Debug.LogWarning("Intento de agregar modelo nulo a DataEdificio");
            return;
        }

        // Asegura que cada modelo tenga un nombre �nico
        model.name = $"Model_{DataEdificio.Count + 1}";

        // Asignar posici�n base o incremental
        if (spawnParent)
            model.transform.SetParent(spawnParent, false);

        model.transform.position = spawnPosition;
        model.SetActive(false);

        // Agregar al listado
        DataEdificio.Add(model);

        Debug.Log($"Modelo agregado a DataEdificio: {model.name}");
        UpdateStatus($"Modelo {model.name} cargado correctamente.");
    }


    private void UpdateStatus(string msg)
    {
        Debug.Log(msg);
        if (statusText)
            statusText.text = msg;
    }
}
