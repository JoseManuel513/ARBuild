using UnityEngine;
using UnityEngine.UI;
using ZXing;
using TMPro;
using System.Collections;

public class QRReader : MonoBehaviour
{
    public RawImage _rawImageBackground;
    public AspectRatioFitter _aspectRatioFitter;
    public RectTransform _scanZone;
    public DriveDownloader downloader;
    public Botones listaPisos;
    public GameObject loadImage;
    public GameObject prefabTexto;
    public GameObject QR_UI;
    public GameObject AR_UI;

    public GameObject camera;
    public GameObject AR_Cam;
    public GameObject AR_Trg;

    [Header("Configuraci�n de Calidad")]
    public int targetWidth = 1920;  // Resoluci�n objetivo
    public int targetHeight = 1080; // Resoluci�n objetivo
    public int requestedFPS = 30;   // Cuadros por segundo

    private bool _isCamAvailable;
    private WebCamTexture _cameraTexture;
    private BarcodeReader _barcodeReader;

    void Start()
    {
        _barcodeReader = new BarcodeReader();
        _barcodeReader.Options.TryHarder = true; // Mejorar detecci�n
        _barcodeReader.AutoRotate = true;        // Rotaci�n autom�tica

        SetUpCamera();
    }

    void Update()
    {
        UpdateCameraRender();

        // Escaneo autom�tico opcional cada 2 segundos
        // AutoScan();
    }

    private void SetUpCamera()
    {
        WebCamDevice[] devices = WebCamTexture.devices;

        if (devices.Length == 0)
        {
            _isCamAvailable = false;
            return;
        }

        // Buscar la mejor c�mara (trasera preferentemente)
        WebCamDevice selectedDevice = devices[0];
        foreach (WebCamDevice device in devices)
        {
            if (!device.isFrontFacing)
            {
                selectedDevice = device;
                break;
            }
        }

        Debug.Log($"Usando c�mara: {selectedDevice.name}");

        // Usar resoluci�n nativa o la m�s alta disponible
        Resolution[] resolutions = GetAvailableResolutions(selectedDevice.name);
        if (resolutions.Length > 0)
        {
            // Seleccionar la resoluci�n m�s alta disponible
            Resolution highestRes = resolutions[resolutions.Length - 1];
            targetWidth = highestRes.width;
            targetHeight = highestRes.height;
            Debug.Log($"Resoluci�n seleccionada: {targetWidth}x{targetHeight}");
        }

        // Crear WebCamTexture con mejor resoluci�n
        _cameraTexture = new WebCamTexture(
            selectedDevice.name,
            targetWidth,
            targetHeight,
            requestedFPS
        );

        // Configurar filtro para mejor calidad
        _cameraTexture.filterMode = FilterMode.Trilinear;
        _cameraTexture.wrapMode = TextureWrapMode.Clamp;

        _cameraTexture.Play();
        _rawImageBackground.texture = _cameraTexture;
        _isCamAvailable = true;

        StartCoroutine(WaitForCameraInitialization());
    }

    private Resolution[] GetAvailableResolutions(string cameraName)
    {
        // En algunos dispositivos podemos obtener resoluciones disponibles
        // Esta es una implementaci�n b�sica - puedes expandirla
        return new Resolution[]
        {
            new Resolution { width = 640, height = 480 },
            new Resolution { width = 1280, height = 720 },
            new Resolution { width = 1920, height = 1080 },
            new Resolution { width = 3840, height = 2160 }
        };
    }

    private IEnumerator WaitForCameraInitialization()
    {
        // Esperar a que la c�mara se inicialice completamente
        int maxWait = 50; // 5 segundos m�ximo
        while (_cameraTexture != null && _cameraTexture.width < 100 && maxWait > 0)
        {
            yield return new WaitForSeconds(0.1f);
            maxWait--;
        }

        if (_cameraTexture != null && _cameraTexture.width > 100)
        {
            Debug.Log($"C�mara inicializada: {_cameraTexture.width}x{_cameraTexture.height}");
            UpdateCameraRender();
        }
        else
        {
            _isCamAvailable = false;
        }
    }

    private void UpdateCameraRender()
    {
        if (!_isCamAvailable || _cameraTexture == null || !_cameraTexture.isPlaying)
            return;

        // Actualizar aspect ratio
        float ratio = (float)_cameraTexture.width / (float)_cameraTexture.height;
        _aspectRatioFitter.aspectRatio = ratio;

        // Corregir rotaci�n
        int orientation = -_cameraTexture.videoRotationAngle;
        _rawImageBackground.rectTransform.localEulerAngles = new Vector3(0, 0, orientation);

        // Escalar la textura para mejor calidad
        _rawImageBackground.rectTransform.sizeDelta = new Vector2(
            _cameraTexture.width,
            _cameraTexture.height
        );
    }

    public void OnClickScan()
    {
        Scan();
    }

    private void Scan()
    {

        try
        {
            // Obtener p�xeles de toda la textura (no solo del scanZone)
            Color32[] pixels = _cameraTexture.GetPixels32();

            Result result = _barcodeReader.Decode(
                pixels,
                _cameraTexture.width,
                _cameraTexture.height
            );

            if (result != null)
            {
                Debug.Log($"QR: {result.Text} - Formato: {result.BarcodeFormat}");

                // Opcional: procesar el resultado
                ProcessQRResult(result.Text);
            }
            else
            {
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Error en Scan: {ex.Message}");
        }
    }

    // Escaneo autom�tico opcional
    private void AutoScan()
    {
        if (Time.frameCount % 120 == 0) // Escanear cada ~2 segundos (60 FPS * 2)
        {
            Scan();
        }
    }

    public void ProcessQRResult(string qrText)
    {
        loadImage.SetActive(true);
        QR_UI.SetActive(false);
        if (downloader == null)
        {
            Debug.LogError("DriveDownloader no asignado en el inspector.");
            loadImage.SetActive(false);
            return;
        }

        // Separar IDs por delimitadores
        string[] ids = qrText.Split("|||" , System.StringSplitOptions.RemoveEmptyEntries);

        if (ids.Length == 0)
        {
            Debug.LogWarning("No se detectaron IDs v�lidos en el QR.");
            loadImage.SetActive(false);
            return;
        }

        Debug.Log($"Se encontraron {ids.Length} IDs en el QR.");

        StartCoroutine(DownloadModelsSequentially(ids));
    }
    private IEnumerator DownloadModelsSequentially(string[] ids)
    {
        // Descarga secuencial de todos los modelos
        foreach (string id in ids)
        {
            string cleanId = id.Trim();
            if (string.IsNullOrEmpty(cleanId)) continue;

            Debug.Log($"[Secuencial] Descargando modelo con ID: {cleanId}");

            // Espera a que termine cada descarga antes de pasar al siguiente
            yield return StartCoroutine(downloader.DownloadAndLoadGLB(cleanId));

            Debug.Log($"[Secuencial] Modelo con ID {cleanId} completado.");
        }

        // Guardar en listaPisos
        listaPisos.partesEdificio = downloader.DataEdificio.ToArray();

        // Activar el primer modelo (edificio base)
        if (downloader.DataEdificio.Count > 0)
            downloader.DataEdificio[0].SetActive(true);

        // Ocultar imagen de carga
        //camera.SetActive(false);
        AR_Cam.SetActive(true);

        AR_UI.SetActive(true);
        AR_Trg.SetActive(true);

        // Crear botones din�micamente
        CrearBotonesDeModelos();

        loadImage.SetActive(false); 

        Debug.Log("Todas las descargas han terminado.");
    }

    private void CrearBotonesDeModelos()
    {
        float posY = 40f; // posici�n inicial en Y
        int total = downloader.DataEdificio.Count;

        for (int i = 0; i < total; i++)
        {
            GameObject nuevoBoton = Instantiate(prefabTexto, listaPisos.gameObject.transform);
            RectTransform rect = nuevoBoton.GetComponent<RectTransform>();
            rect.anchoredPosition = new Vector2(rect.anchoredPosition.x, posY);

            // Configurar texto
            TextMeshProUGUI texto = nuevoBoton.GetComponentInChildren<TextMeshProUGUI>();
            if (texto != null)
            {
                texto.text = (i == 0) ? "Edificio" : $"Piso {i}";
            }

            // Configurar bot�n y evento
            Button btn = nuevoBoton.GetComponentInChildren<Button>();
            if (btn == null)
            {
                Debug.LogError($"El prefab {prefabTexto.name} no tiene componente Button.");
            }
            else
            {
                int index = i;
                btn.onClick.AddListener(() => Debug.Log($"Bot�n {index} presionado."));
                btn.onClick.AddListener(() => listaPisos.MostrarPartes(index));
                Debug.Log($"Listener agregado a bot�n {index}");
            }
            //nuevoBoton.GetComponentInChildren<Button>().onClick.AddListener(() => listaPisos.MostrarPartes(i));

            // Actualizar posici�n Y para el siguiente
            posY -= 13f;
        }

        Debug.Log($"{total} botones creados en el men�.");
    }



    // M�todo para cambiar la resoluci�n en tiempo de ejecuci�n
    public void SetResolution(int width, int height)
    {
        if (_cameraTexture != null && _cameraTexture.isPlaying)
        {
            _cameraTexture.Stop();
            _cameraTexture = new WebCamTexture(_cameraTexture.deviceName, width, height, requestedFPS);
            _cameraTexture.Play();
            _rawImageBackground.texture = _cameraTexture;
        }
    }

    void OnDestroy()
    {
        if (_cameraTexture != null && _cameraTexture.isPlaying)
        {
            _cameraTexture.Stop();
        }
    }

    void OnApplicationPause(bool pauseStatus)
    {
        if (_cameraTexture != null)
        {
            if (pauseStatus)
            {
                _cameraTexture.Pause();
            }
            else
            {
                _cameraTexture.Play();
            }
        }
    }
}