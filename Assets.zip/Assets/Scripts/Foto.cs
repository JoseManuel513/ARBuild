using UnityEngine;
using System.IO;

public class MobileScreenshot : MonoBehaviour
{
    [SerializeField] private Camera myCamera;

    public void TakeScreenshot()
    {
        StartCoroutine(CaptureScreenshot());
    }

    private System.Collections.IEnumerator CaptureScreenshot()
    {
        yield return new WaitForEndOfFrame(); // Espera que termine el frame

        int width = Screen.width;
        int height = Screen.height;

        RenderTexture renderTexture = new RenderTexture(width, height, 24);
        myCamera.targetTexture = renderTexture;

        Texture2D screenshot = new Texture2D(width, height, TextureFormat.RGB24, false);
        myCamera.Render();

        RenderTexture.active = renderTexture;
        screenshot.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        screenshot.Apply();

        myCamera.targetTexture = null;
        RenderTexture.active = null;
        Destroy(renderTexture);

        byte[] bytes = screenshot.EncodeToPNG();

        //Guardar en carpeta segura para m�viles
        string filePath = Path.Combine(Application.persistentDataPath, "screenshot.png");
        File.WriteAllBytes(filePath, bytes);

        Debug.Log($"Screenshot guardado en: {filePath}");
    }
}
