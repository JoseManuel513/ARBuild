using System.Collections;
using UnityEngine;

public class Precarga : MonoBehaviour
{
    public GameObject loadingScreen; // Tu imagen de fondo
    public GameObject[] objectsToLoad; // Todos tus edificios/objetos pesados

    void Start()
    {
        StartCoroutine(WaitAndHide());
    }

    private IEnumerator WaitAndHide()
    {
        // 1. Mostrar pantalla de carga
        if (loadingScreen != null)
        {
            loadingScreen.SetActive(true);
        }

        // 2. Esperar 5 segundos
        yield return new WaitForSeconds(0.65f);

        //objectsToLoad[0].SetActive(false);
        //sobjectsToLoad[1].SetActive(false);

        // 3. Ocultar pantalla de carga
        if (loadingScreen != null)
        {
            loadingScreen.SetActive(false);
        }
    }
}