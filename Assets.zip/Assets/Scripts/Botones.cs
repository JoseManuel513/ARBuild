using UnityEngine;
using System.Collections;

public class Botones : MonoBehaviour
{
    public GameObject[] partesEdificio = new GameObject[4];     // Lista de las partes del edificio

    public RectTransform target;     // El objeto UI a mover
    public float moveDuration = 0.5f; // Duraci�n completa del movimiento
    public float x1 = -224f;          // Posici�n inicial
    public float x2 = 66f;          // Posici�n destino

    private bool movingToX2 = false; // Estado: hacia cu�l extremo se mueve
    private Coroutine moveCoroutine;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void MostrarOpciones()
    {
        // Si ya hay una animaci�n, no se cancela: solo invierte la direcci�n
        movingToX2 = !movingToX2;

        // Si no hay una animaci�n en curso, inicia una
        if (moveCoroutine == null)
            moveCoroutine = StartCoroutine(MoveSmooth());
    }

    private IEnumerator MoveSmooth()
    {
        // Movimiento continuo, incluso si se invierte mientras est� en curso
        while (true)
        {
            // Posiciones actuales y objetivo
            Vector2 pos = target.anchoredPosition;
            float targetX = movingToX2 ? x2 : x1;

            // Distancia restante
            float distance = Mathf.Abs(targetX - pos.x);

            // Duraci�n proporcional seg�n lo que falte del recorrido
            float duration = (distance / Mathf.Abs(x2 - x1)) * moveDuration;
            float elapsed = 0f;

            Vector2 startPos = pos;
            Vector2 endPos = new Vector2(targetX, pos.y);

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.SmoothStep(0, 1, elapsed / duration);
                target.anchoredPosition = Vector2.Lerp(startPos, endPos, t);

                // Si cambias direcci�n a mitad del recorrido, reinicia el bucle
                if ((movingToX2 && endPos.x != x2) || (!movingToX2 && endPos.x != x1))
                    break;

                yield return null;
            }

            target.anchoredPosition = new Vector2(targetX, pos.y);

            // Espera siguiente cambio de direcci�n
            yield return null;

            // Si ya est� en su destino y no cambi� direcci�n, pausa el bucle
            if ((movingToX2 && Mathf.Approximately(target.anchoredPosition.x, x2)) ||
                (!movingToX2 && Mathf.Approximately(target.anchoredPosition.x, x1)))
            {
                moveCoroutine = null;
                yield break;
            }
        }
    }

    public void MostrarPartes(int show)
    {
        if (!partesEdificio[show].activeSelf)
        {
            foreach (GameObject parte in partesEdificio)
            {
                parte.SetActive(false);
            }
            if (show < partesEdificio.Length)
            {
                partesEdificio[show].SetActive(true);
            }
        }

        MostrarOpciones();
    }
}
